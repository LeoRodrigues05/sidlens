# Setup, CCE, and ZCR validation — 15 September 2026

This check extends the [14 September validation](validation-2026-09-14.md).
Commands and recipient instructions are in [the run guide](run-experiments.md).
The validated implementation is the current local working tree; commit and
push these changes before asking a recipient to clone them.

## Installation and command checks

- Created a fresh Python 3.12 venv and ran the maintained `setup` installation,
  including PyTorch 2.6.0+cu124 and all direct requirement pins. Reused the
  existing, hash-verified Qwen model and Industrial data; no new model download
  was necessary. `pip check`, runtime imports, exact direct-version checks,
  and all 27 native Diff cache tables passed.
- Installed optional `requirements-zcr.txt` through `setup --with-zcr`.
  FAISS 1.15.0 and the pinned NumPy 1.26.3 passed actual quantizer generation.
- **168 tests passed**, including real tiny AR/Diff training, checkpoint reload,
  corrected decoding, CCE formulas/schema checks, portable geometry, both
  horizon cohorts, native/ZCR cache isolation, checkpoint/index mismatch,
  input tampering, and launcher-to-worker command propagation.
- Runtime preflight now rejects drift from direct package pins. The original
  shared `.conda` has NumPy 2.4.6 and therefore fails the NumPy 1.26.3 pin.
  That shared environment and its active training jobs were left intact.
  Use a new environment for the maintained pinned workflow. Historical and new
  environments are explicitly different; do not silently pool their results.
- AR now passes the requested seed to both Trainer's `seed` and `data_seed`.
  Previously, a non-42 command-line seed could coexist with Trainer's default
  42. This does not imply every old seed run was identical, but it prevents
  treating their Trainer/data seeds as fully controlled without auditing them.
- External AR evaluation no longer requires the original base Qwen model when
  an explicit trained checkpoint is supplied.

## Real Industrial workflow checks

Four Diff cells completed actual training, checkpoint selection/export,
checkpoint reload, corrected test decoding, and provenance verification:

| Prediction | Assignment | Execution | Validation/test scope |
|---|---|---|---|
| next-item | native RQ-KMeans 3×128 | CPU, normal 5.37M architecture | 2 examples each |
| next-item | ZCR RQ-KMeans 3×128 | CPU, normal 5.37M architecture | 2 examples each |
| next2item | native RQ-KMeans 3×128 | CPU, normal 5.37M architecture | 2 examples each |
| next2item | ZCR RQ-KMeans 3×128 | CPU, normal 5.37M architecture | 2 examples each |

Each used seed 17, 32 training examples, one epoch, beam/top-K 3. Next-item
tested the combined `train` workflow; next2item tested `train --train-only`
followed by the separate `eval` command. Both next-item exports contain strict
CCE with denominator 2; next-two exports contain tuple/slot metrics and no
invented pair CCE. Raw cohorts and event IDs match across assignments.
These bounded numbers are infrastructure checks, not recommendation results.

The real **Qwen2.5-1.5B AR / ZCR / next2item / RQ-KMeans 3×128 / seed17**
smoke completed on one A100-40GB (`gpu-11`, Slurm `244127_0`). It trained
20 mixed-objective examples for five optimizer steps, validated on four
examples, selected checkpoint 3 by validation loss, exported/reloaded the
selected model, and completed corrected whole-pair evaluation on two examples
with beam/top-K 3. Saved SFT statistics confirm `trainer_seed=17` and
`data_seed=17`. Both phase results are `completed`, and their artifact hashes
were verified. Its raw evaluation examples match the ZCR Diff next2item run.
These are real model-training/decoding checks in the newly installed stack.

Repeated Diff `eval` commands verified and skipped completed phases without
overwriting them. The source snapshot for all five cells is
`68c23bbaee81e1f5e7b6df1c26a8c8f29695cc19476571fc9a9b5f85f8e31087`.

## ZCR completion and geometric evidence

`onediffrec.py zcr --method rqkmeans --digits 3 --size 128 --threads 96
--execute` completed against all 3,105 Industrial items in the fresh environment.
Every reconstructed native SID matched. The mapping, all codebook arrays,
final-stage residuals/centroids, and serialized FAISS quantizer are byte-identical
to the separately verified reconstruction in the original environment.

The ZCR mapping itself also matches the archived September 7 mapping:

- 2,195 → 3,105 distinct SIDs; 1,391 → 0 items in collisions.
- 910 tail changes (29.31% of items), with every prefix preserved.
- Final-stage squared distortion increases by approximately 4.598%.
- Both mappings use the same 384 SID tokens, preserving AR vocabulary size.
- All bundle-member hashes and fitted FAISS serialization/reload checks pass.

The bundle contains native and ZCR indexes/code arrays, explicit row-to-item
identities, all fitted codebooks, final-stage geometry, statistics, a reloadable
FAISS state, and a manifest. It is about 41.5 MB, retained once per assignment;
regular training links it through hashes without copying it into each run.

Reconstruction with one or four FAISS threads failed the exact-native-match
guard; 96 worked for this configuration. Transfer the fitted bundle between
machines. This does not prove equality to the unsaved historical original
centroids. The tested generic geometry CLI also reproduced the same ZCR map
from the archived final-stage arrays without refitting.

RQ-VAE/MQ geometry ingestion is implemented and tested with supplied arrays.
Actual historical fitted states/geometry remain missing, so no real new
RQ-VAE/MQ codebooks are claimed. MQ requires its final head's own input space;
residual subtraction is invalid for parallel heads. Industrial MQ 3×128 also
cannot achieve tail-only ZCR: its largest fixed-prefix group has 141 items but
only 128 final codes.

## Retained evidence

Machine-local work root:
`/l/users/leo.rodrigues/onediffrec/handoff/industrial-zcr-v3`.

- `setup.json`, `setup/pip-freeze.txt`: verified runtime and dependency versions.
- `zcr/industrial/rqkmeans_3codebook_128`: fresh verified geometry bundle.
- `plans/`, `sources/`: exact launch plans and frozen executable source.
- `experiments/verified-20260915/smoke/industrial/`: model/checkpoint artifacts,
  logs, predictions, metrics, and phase provenance.
- `validation/verified-smokes.json`: verified Diff results and byte comparisons.

Installation and test logs are retained in the parent `handoff/` directory:
`fresh-setup-20260915.log`, `fresh-setup-zcr-20260915.log`,
`tests-final-20260915.log`, and `zcr-fresh-environment-20260915.log`.

Office end-to-end training, full-duration grids, model convergence, and
multi-GPU execution were not repeated here. The recipient should complete a
smoke run on their own machine before scaling up.
