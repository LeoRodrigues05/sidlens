# Industrial next-item CCE: audited co-author bundle

This bundle contains all **18 validated historical CCE configurations** available for the Industrial dataset: three tokenizer families × depths 3/4/5 × codebook sizes 128/512. There are no qualifying width-256 CCE results. Scores are unweighted row means over 3,681 next-item examples (1,606 unique users) and are reported in **percentage points**. CCE follows the single-target formulation in [Zhang et al., arXiv:2605.25330](https://arxiv.org/pdf/2605.25330).

## Files

- `cce_all_cutoffs_long.csv`: all 108 configuration/cutoff rows for K = 1, 3, 5, 10, 20, 50.
- `cce_at10.csv`: the 18 @10 rows with gaps, inflation, and raw/corrected ranks.
- `figure1_cce_absolute_scores.*`: absolute SID and CCE scores for every configuration.
- `figure2_collision_vs_correction.*`: paper-defined collision-item rate versus absolute correction.
- `figure3_hit_rank_reversal.*`: raw-to-corrected Hit@10 ranks.
- `source_industrial_nextitem_paper_cce_v1.csv`: checksum-locked computational source (`score_scale=fraction`).
- `source_cce_next_item_audit.csv`: independently preserved @10 audit (`*_pct` columns are percentage points).
- `provenance.json` and `checksums.sha256`: validation metadata and portable checksums.
- `make_cce_figures.py`: this reproducible build script.
- `requirements.txt`: exact plotting-library versions used for this export.

Every PNG is 300 dpi; matching PDF and text-preserving SVG files are included for full-page or slide use.

## Figure-specific captions

**Figure 1 — Absolute CCE results.** SID-level and collision-corrected item-level Hit@10 and NDCG@10 for all 18 configurations. Open circles are SID metrics; colored diamonds are CCE item metrics; connecting segments are the absolute correction. Rows are ordered by CCE ItemHit@10. Parenthetical percentages are catalog items belonging to non-singleton complete-SID groups.

**Figure 2 — Collision rate and correction size.** Paper-defined colliding-item rate against the absolute SID−CCE correction for Hit@10 and NDCG@10. Each point is one configuration; color identifies tokenizer family and shape identifies codebook size. Insets enlarge the 0–2% collision region. Spearman correlations summarize this fixed grid descriptively and are not causal estimates.

**Figure 3 — Rank reordering.** Observed Hit@10 rank before and after CCE for all 18 configurations. Labels report scores rounded to two decimals; line color identifies tokenizer family. Ranking is descriptive for one retained training run per configuration and should not be interpreted as a significance result.

## Rebuild

From this directory, with Python 3.11 available:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
MPLCONFIGDIR=/tmp/mpl-cce .venv/bin/python make_cce_figures.py --output-dir rebuilt
```

The script defaults to the two bundled checksum-locked sources. It will fail closed if either source hash, cohort shape, protocol, units, grid, or independently audited @10 values differ.

## Descriptive takeaways

- The median correction is **4.127 points for Hit@10** and **3.537 points for NDCG@10**.
- Collision-item rate and the absolute correction are strongly associated within this grid (Spearman ρ = **0.913** for Hit and **0.944** for NDCG). This is descriptive, not causal.
- Raw and corrected rankings disagree: Spearman ρ = **-0.346** for Hit and **-0.591** for NDCG.
- **RQ-VAE 5×512** has the highest observed CCE ItemHit@10 (14.1538), and **RQ-VAE 5×512** has the highest observed CCE ItemNDCG@10 (9.7369). These are observed one-seed scores, not statistically established winners.

## Audited @10 table (four-decimal display)

| Configuration | SID H@10 | CCE IH@10 | H gap | SID N@10 | CCE IN@10 | N gap | Coll. items |
|---|---:|---:|---:|---:|---:|---:|---:|
| Parallel MQ 3×128 | 23.0101 | 9.5287 | 13.4813 | 15.6182 | 5.9951 | 9.6232 | 54.5250% |
| Parallel MQ 3×512 | 17.8756 | 10.1755 | 7.7001 | 13.2147 | 6.7501 | 6.4645 | 30.7246% |
| Parallel MQ 4×128 | 21.8691 | 11.2760 | 10.5931 | 15.7651 | 7.0983 | 8.6668 | 37.0048% |
| Parallel MQ 4×512 | 18.9894 | 12.4678 | 6.5216 | 14.7332 | 7.9980 | 6.7351 | 22.6731% |
| Parallel MQ 5×128 | 16.6802 | 10.6992 | 5.9810 | 12.8653 | 7.1410 | 5.7243 | 25.8937% |
| Parallel MQ 5×512 | 15.4306 | 9.8755 | 5.5551 | 11.0820 | 6.7455 | 4.3365 | 18.4541% |
| RQ-KMeans 3×128 | 24.0152 | 12.6377 | 11.3775 | 17.0918 | 7.8677 | 9.2241 | 44.7987% |
| RQ-KMeans 3×512 | 13.8549 | 11.1555 | 2.6994 | 10.1675 | 7.4302 | 2.7373 | 16.0386% |
| RQ-KMeans 4×128 | 19.4512 | 12.9069 | 6.5444 | 15.3237 | 7.9801 | 7.3436 | 29.3076% |
| RQ-KMeans 4×512 | 15.1861 | 12.5302 | 2.6559 | 11.1184 | 8.6024 | 2.5160 | 9.6618% |
| RQ-KMeans 5×128 | 19.6957 | 11.8903 | 7.8055 | 14.5204 | 7.8097 | 6.7107 | 21.7713% |
| RQ-KMeans 5×512 | 12.0891 | 11.9804 | 0.1087 | 9.3737 | 9.3265 | 0.0472 | 0.6441% |
| RQ-VAE 3×128 | 12.5238 | 12.0295 | 0.4942 | 9.2964 | 8.3490 | 0.9474 | 1.5459% |
| RQ-VAE 3×512 | 14.0723 | 14.0451 | 0.0272 | 10.1643 | 9.3891 | 0.7752 | 0.7729% |
| RQ-VAE 4×128 | 12.7954 | 12.7683 | 0.0272 | 9.4840 | 8.7204 | 0.7635 | 0.7729% |
| RQ-VAE 4×512 | 13.1486 | 13.0807 | 0.0679 | 9.9475 | 9.0635 | 0.8840 | 0.7085% |
| RQ-VAE 5×128 | 13.6919 | 13.6104 | 0.0815 | 10.2760 | 9.4409 | 0.8350 | 0.7085% |
| RQ-VAE 5×512 | 14.2081 | 14.1538 | 0.0543 | 10.6195 | 9.7369 | 0.8825 | 0.7085% |

`H gap` and `N gap` are SID minus CCE in percentage points. The CSV also reports paper-style relative inflation as `(SID / CCE − 1) × 100%`.

## Shared methods note suitable for captions

> Historical Industrial next-item AR results from this cluster (one retained run per configuration; 3,681 examples/1,606 users; 3,105-item catalog). Scores are percentage points. CCE was recomputed from saved SID beams and the complete catalog using the paper's single-target collision-group expansion; SID @K counts SID ranks, whereas Item @K counts expanded item positions. Gap is SID−CCE in percentage points and Inflation is `(SID/CCE−1)×100%`. Colliding items is the paper's item-weighted rate. Trailing blank beam slots were removed and short returned rankings remained in the denominator. These are not next-2 results or a reproduction of the paper's dataset/model/configuration; Parallel MQ is not MQL4GRec.

## Scope and limitations

- This is the validated historical **single next-item AR/SFT cohort**, not the running next-2 sweep and not the new canonical-v3 cohort.
- Each configuration has one retained training run/seed. No training-seed uncertainty is available; the figures therefore contain no inferential error bars.
- After trailing blank padding is removed, 3.74% of configuration-example rankings have fewer than 10 retained SIDs, rising to 9.22% at K=20 and 36.95% at K=50. Returned rankings are scored as-is and all examples remain in the denominator under the documented compatibility policy.
- The paper's `Coll.%` is the fraction of catalog items belonging to non-singleton SID groups. It is not duplicate excess. Both fields are kept separately in the compiled CSVs.
- The local Parallel MQ tokenizer must not be identified with the paper's collision-free MQL4GRec baseline.
- Capacity-only width-256 rows, next-2 results, and n=2 smoke outputs were excluded because they are not qualifying CCE evaluations.

Bundled computational source: `source_industrial_nextitem_paper_cce_v1.csv`  
SHA-256: `af561b7ec6ccf87f0ace5b8d20ecdcb78b6d82c0a44b1770bf0d7d97f5d7384f`  
The original cluster location is recorded in `provenance.json`.
