# Next-2-item prediction: figures

Thirteen figures covering every angle the current pair-prediction runs support,
on Industrial_and_Scientific at codebook 256. Regenerate from the repository
root with:

```bash
.conda/bin/python scripts/diagrams/two_item/make_all.py
```

Read [`analysis_report.md`](analysis_report.md) for the findings, scope, and
interpretation limits. Tidy source tables are under [`data/`](data/).

| Figure | Question answered |
|---|---|
| [`fig01_two_item_grid`](fig01_two_item_grid.png) | What does each SID configuration score on the pair task, under each paradigm? |
| [`fig02_paradigm_gap_by_depth`](fig02_paradigm_gap_by_depth.png) | Where does the diffusion decoder win on pairs, and how fast does that win decay with $k$? |
| [`fig03_next1_vs_next2`](fig03_next1_vs_next2.png) | What does requiring the second item cost, relative to the same model's single-item score? |
| [`fig04_rank_depth_curves`](fig04_rank_depth_curves.png) | How does each paradigm's pair score grow with the cut-off? |
| [`fig05_slot_decomposition`](fig05_slot_decomposition.png) | Which half of the pair does the model actually get right? |
| [`fig06_first_slot_vs_single_task`](fig06_first_slot_vs_single_task.png) | Does asking for two items damage the first prediction? |
| [`fig07_pair_ordering_errors`](fig07_pair_ordering_errors.png) | How often is the pair right as a set but wrong as a sequence? |
| [`fig08_near_miss_prefix_depth`](fig08_near_miss_prefix_depth.png) | How near does the top-ranked guess get, digit by digit? |
| [`fig09_beam_yield`](fig09_beam_yield.png) | What does constrained decoding actually return before scoring? |
| [`fig10_collision_and_utilization`](fig10_collision_and_utilization.png) | Does the collision/performance association reappear on the pair task? |
| [`fig11_training_dynamics`](fig11_training_dynamics.png) | What do the two training regimes behind the table look like? |
| [`fig12_beam_ordering_ablation`](fig12_beam_ordering_ablation.png) | Does DiffGRM's confidence-ordered unmasking earn its keep on pairs? |
| [`fig13_cost_vs_accuracy`](fig13_cost_vs_accuracy.png) | What did these runs cost, and does spending more help? |

Every figure is written as a 400-dpi PNG and a vector PDF.
