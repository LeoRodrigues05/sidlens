# Updated workbook diagrams

Sixteen figures cover both datasets, both recommendation tasks, all six ranking metrics, tokenizers, SID depth/codebook size, model variants, collision rates, and completed-run efficiency.

[Open the local gallery](index.html) · [All figures in one PDF](all_figures.pdf) · [Overview](overview.png)

![Figure overview](overview.png)

## Regenerate

From the repository root:

```bash
.conda/bin/python diagrams/diagramsv2/make_all.py
```

The script resolves its default workbook relative to its own location, so it also works from another directory. Optional `--workbook PATH` and `--output PATH` flags select another workbook with this schema or output folder.

For another Python environment, install `requirements.txt` from this folder first. Rendering is offline with Matplotlib's Agg backend. Each figure is a 300-dpi PNG and a vector PDF with embedded TrueType fonts.

## Workbook coverage and reconciliation

Source: `data/OneDiffRec_MainExcel.xlsx` (actual input recorded in `audit.json`: `/home/leo.rodrigues/onediffrec/OneDiffRec/data/OneDiffRec_MainExcel.xlsx`).
SHA-256: `0f85c66e2c16626dd1162915ba8110012d82c31a7af608fa5a95be395b78f0b3`.

| Sheet | Treatment |
|---|---|
| Industrial_Reported | Both stacked task tables; model variants and duplicate baseline retained. |
| Office_Reported | Both task tables; every pending row retained. Side notes preserved in occupied-cell export. |
| AllResults | Cross-checked observation by observation against the reported sheets. Repeated rows are not double-counted. |
| Efficiency | 62 primary observations; four summary rows checked separately, not counted as observations. |
| Literature | All 24 entries exported to [literature.md](literature.md) and CSV; qualitative context is not plotted as experiment data. |

The reported sheets contain **221 rows / 127 complete observations**. `AllResults` contains 199 rows / 105 complete observations and omits **18 Industrial Mask Diffusion results at codebooks 128/512 plus four AR model variants**. The shared observations agree. The canonical table therefore uses the reported sections, supplementing only genuinely new observations from AllResults if present.

One nominal baseline is ambiguous: Industrial, next-item, RQ-VAE, codebook 256, depth 3, Qwen2.5-1.5B. `Industrial_Reported` rows **21 and 22** (legacy `workbook_row` values 52/53) give HR@10 **11.78 and 12.85**. No column distinguishes the training setup. Both observations appear in figure 9; **neither is selected or averaged into core comparisons**. Coverage counts that SID setting once as recorded but ambiguous. The two main heatmaps mark it unavailable for core analysis.

Excluding these two ambiguous observations and the four additional model variants leaves **215 core rows / 121 complete observations**.

| Dataset | Task | AR recorded / planned | Diffusion recorded / planned |
|---|---|---:|---:|
| Industrial | next-item | 27/27 (1 ambiguous) | 27/27 |
| Industrial | next-2-item | 10/27 | 22/27 |
| Office | next-item | 9/27 | 27/27 |
| Office | next-2-item | 0/27 | 0/27 |

Office side notes `P8:U11` are preserved but not used as completion counts. They list 26/27 Office next-item diffusion and 21/27 Industrial next-two-item diffusion; the actual metric rows contain 27/27 and 22/27. Their average-time values have no units, so they are not used as measured efficiency.

## Notable comparisons

All differences below are **diffusion minus AR**, in reported percentage points, with one vote per unambiguous matched SID configuration. These are descriptive configuration means, not repeated-seed estimates.

| Dataset / task | Matched configurations | Mean HR@10 gap | Mean NDCG@10 gap |
|---|---:|---:|---:|
| Industrial / next-item | 26 | -1.784 | -1.272 |
| Industrial / next-2-item | 10 | -1.763 | +0.025 |
| Office / next-item | 9 | +6.650 | +5.028 |

At the **same 8 codebook-256 configurations** in both datasets (figure 16), the mean HR@10 gap is **-0.940** on Industrial and **+6.817** on Office. This controls the nominal tokenizer/depth/codebook coverage difference; it does not make the datasets or model training protocols identical.

The six-metric view (figure 10) shows why HR@10 alone is incomplete: Industrial next-two-item has a negative mean HR@10 gap while its mean NDCG@10 gap is near zero. The same ten matched configurations are used for both metrics.

- Industrial: among all 27 diffusion next-item configurations, collision vs. HR@10 has Spearman ρ = +0.852; vs. NDCG@10, ρ = +0.815. This is an association across varying design settings, not a causal effect.
- Office: among all 27 diffusion next-item configurations, collision vs. HR@10 has Spearman ρ = +0.386; vs. NDCG@10, ρ = +0.190. This is an association across varying design settings, not a causal effect.

| AR task | Configurations | Evaluation ms/example | Evaluation share of train + eval GPU-hours |
|---|---:|---:|---:|
| next-item | 18 | 45.1–58.1 | 3.9–5.6% |
| next-2-item | 10 | 646.6–965.8 | 39.2–49.7% |

These task ranges have different codebook coverage: next-item AR efficiency is at 128/512; next-two-item is at 256 plus one MQ / 512 / 3d observation. They are not a controlled task-only latency ratio.

## Figures

| Figure | Caption |
|---|---|
| [fig01_result_coverage](fig01_result_coverage.png) · [PDF](fig01_result_coverage.pdf) | 27 planned SID configurations per task/family. Four extra model variants are outside this grid. The hatched Industrial AR cell has two conflicting results; both are retained as variants and excluded from core comparisons. |
| [fig02_next_item_hr10](fig02_next_item_hr10.png) · [PDF](fig02_next_item_hr10.pdf) | Reported HR@10 in percentage points; shared color scale from 0 to 25. AR = Qwen2.5-1.5B. Gray / — = pending, or ambiguous Industrial RQ-VAE / 256 / 3d AR. Diffusion-family labels follow the workbook. |
| [fig03_next_item_ndcg10](fig03_next_item_ndcg10.png) · [PDF](fig03_next_item_ndcg10.pdf) | Reported NDCG@10 in percentage points; shared color scale from 0 to 18. AR = Qwen2.5-1.5B. Gray / — = pending, or ambiguous Industrial RQ-VAE / 256 / 3d AR. Diffusion-family labels follow the workbook. |
| [fig04_next_two_item_grid](fig04_next_two_item_grid.png) · [PDF](fig04_next_two_item_grid.pdf) | Reported percentage points; each metric has its own shared scale starting at zero. Gray / — = pending. Office next-two-item has no recorded metrics. Next-two-item uses graded ordered-pair relevance (AllResults!A1 comment). |
| [fig05_paradigm_gap_by_depth](fig05_paradigm_gap_by_depth.png) · [PDF](fig05_paradigm_gap_by_depth.pdf) | Points = matched SID configurations; dark diamonds = arithmetic means, with pair counts. Positive favors diffusion. Industrial uses 26 pairs across codebooks 128/256/512; Office uses 9 pairs at codebook 256. These are different configuration sets. |
| [fig06_collision_landscape](fig06_collision_landscape.png) · [PDF](fig06_collision_landscape.pdf) | Values = workbook collision percentages; shared scale from 0 to 56%. One observation per dataset/SID configuration. Collision percentages are descriptive tokenizer properties; no collision-corrected accuracy is inferred. |
| [fig07_collision_vs_accuracy](fig07_collision_vs_accuracy.png) · [PDF](fig07_collision_vs_accuracy.pdf) | Diffusion-family next-item results only: all 27 SID configurations per dataset, each counted once. Tokenizer, codebook, and depth also vary; the correlation does not identify a causal collision effect or corrected ranking. |
| [fig08_next_item_vs_next_two](fig08_next_item_vs_next_two.png) · [PDF](fig08_next_item_vs_next_two.pdf) | Industrial, codebook 256. Each line connects a measured task pair for the same tokenizer, depth, and family. AR RQ-VAE / 3d is omitted (ambiguous baseline). Next-two-item uses graded ordered-pair relevance; task score changes are descriptive. |
| [fig09_model_variants](fig09_model_variants.png) · [PDF](fig09_model_variants.pdf) | Rows refer to Industrial_Reported in this workbook. Filled circles = HR@10; open squares = NDCG@10. Qwen2.5-1.5B rows 21 and 22 have different scores but no distinguishing training label; both remain visible and neither defines the core baseline. |
| [fig10_metric_cutoff_gaps](fig10_metric_cutoff_gaps.png) · [PDF](fig10_metric_cutoff_gaps.pdf) | Means use only complete, unambiguous AR–diffusion pairs. Each series keeps the same configuration set across all six metrics. Configuration sets differ between datasets/tasks. No seed replicates are supplied, so no training-uncertainty error bars are inferred. |
| [fig11_reported_gpu_allocation](fig11_reported_gpu_allocation.png) · [PDF](fig11_reported_gpu_allocation.pdf) | All 62 primary Efficiency records (28 AR, 34 DiffGRM) are displayed. Black ticks mark tokenizer medians within each panel; totals sum reported GPU-hours without treating the four workbook summary rows as extra runs. AR uses four A100 GPUs and separate training/evaluation timing. DiffGRM reports a whole Slurm job on one GPU with no GPU model. Panel x scales differ, and neither the totals nor per-configuration points establish a hardware-normalized family speedup. These are retained completed configurations, not the entire experiment budget: the sheet excludes failed, active, aborted, pilot and duplicate earlier attempts. |
| [fig12_ar_training_evaluation_cost](fig12_ar_training_evaluation_cost.png) · [PDF](fig12_ar_training_evaluation_cost.pdf) | All 28 AR configurations · Qwen2.5-1.5B · Industrial · four A100-SXM4-40GB GPUs. Evaluation is 3.9–5.6% of reported GPU-hours for next item, and 39.2–49.7% for next 2 items. Each stacked bar is one recorded configuration; labels give the evaluation share of training plus evaluation GPU-hours. All three panels share the same horizontal scale. The next-2-item C512 record is MQ at depth 3; other next-2-item AR efficiency records use C256. |
| [fig13_ar_depth_latency_throughput](fig13_ar_depth_latency_throughput.png) · [PDF](fig13_ar_depth_latency_throughput.pdf) | AR evaluation ms/example and training samples/s by token depth, with no averaging across codebook sizes. Next-item curves use C128 and C512; next-2-item curves use C256, with one additional C512 MQ point at depth 3. Lines connect observed depths of the same tokenizer/codebook only. The two tasks have independent vertical scales. These are reported timing and throughput values from four-GPU jobs, not batch-one model latency or per-GPU training throughput; tasks and evaluated sequences differ. |
| [fig14_ar_resource_telemetry](fig14_ar_resource_telemetry.png) · [PDF](fig14_ar_resource_telemetry.pdf) | All 28 autoregressive efficiency records include the plotted telemetry: mean and 5th-percentile GPU utilization, peak memory per GPU, mean power per GPU, sampled energy, estimated training EFLOP, and estimated throughput per GPU. Each panel places the telemetry against reported training GPU-hours; this alignment does not establish an identical measurement window for each field. Colors identify tokenizer and circle/square markers identify next-item/next-2-item tasks. Short bars in the utilization panel mark P05 utilization and thin segments link each record's mean and P05. Energy and compute retain their workbook scope, sampling and estimation labels. DiffGRM lacks these telemetry fields. |
| [fig15_ar_accuracy_cost_tradeoffs](fig15_ar_accuracy_cost_tradeoffs.png) · [PDF](fig15_ar_accuracy_cost_tradeoffs.pdf) | 28 unambiguous nominal AR configurations join Efficiency to the complete reported HR@10 values in AllResults. Joins use dataset, task, model, family, tokenizer, codebook size and depth; planned variants and ambiguous repeated baseline results are excluded. No cross-sheet run ID verifies that the accuracy and cost are from the same execution. Colors indicate tokenizer, marker shape indicates codebook size, and labels identify the observed low-cost/high-HR@10 nondominated configurations in each panel. Dashed paths connect these observations as a visual guide, not an interpolated or statistically estimated frontier. Panels compare only AR on the reported four-A100 setup, with task-specific scales; no DiffGRM-to-Mask-Diffusion mapping or cross-family efficiency ratio is inferred. The workbook defines next-2-item HR/NDCG using graded ordered-pair relevance, so accuracy values should be interpreted within each task. |
| [fig16_matched_cross_dataset_gap](fig16_matched_cross_dataset_gap.png) · [PDF](fig16_matched_cross_dataset_gap.pdf) | Codebook 256: 8 identical tokenizer/depth settings with unambiguous paradigm pairs in both datasets. Dark line = mean. RQ-VAE / 3d is excluded from both sides because Industrial has conflicting AR results. Positive favors diffusion. |

## Interpretation and provenance

- Ranking metrics are already in percentage points; no extra ×100 conversion is applied.
- **Next-two-item HR/NDCG uses graded ordered-pair relevance**, as specified in the `AllResults!A1` comment. It must not be interpreted as strict exact-pair accuracy. Next-item and next-two-item scores have different target semantics.
- `Mask Diffusion` and `DiffGRM` are grouped only because the workbook assigns both to `Diffusion-family`. This does not establish identical architectures, training, decoding settings, or runs. Exact model labels remain in `data/results.csv`.
- Blank metrics remain missing, including every Office next-two-item observation. Missingness is never replaced by a zero score. All paired comparisons require both recorded results and exclude the ambiguous AR baseline.
- Collision values and excess counts are retained as reported. The workbook does not provide corrected item-level metrics for these rows; no adjusted leaderboard or causal collision correction is fabricated.
- The workbook provides no seed dispersion. Point spreads describe different configurations, not model training uncertainty; no significance or confidence-interval claims are attached to the figures.
- AR efficiency uses four NVIDIA A100-SXM4-40GB GPUs and separate training/evaluation timing. DiffGRM uses one GPU of unspecified model and whole-Slurm-job timing. Its train/eval split, inference latency, utilization, power, energy, and estimated FLOPs are absent. No family-wide normalized speedup is derived from these incomparable scopes.
- **Efficiency totals cover the retained completed configurations only.** The `Efficiency!A1` comment explicitly excludes failed, active, aborted, pilot, and duplicate earlier attempts. These are not total project compute budgets.
- Figure 15 joins accuracy and efficiency by exact AR model label and nominal dataset/task/tokenizer/codebook/depth. The workbook has no shared run ID, so a match is not proof that both measurements came from the same run. Its highlighted frontier is an observed descriptive trade-off, subject to the reported metric and collision limitations.
- Sampled energy, estimated training EFLOP, and estimated throughput retain their workbook labels and scope. They are not hardware-counter measurements or whole-system energy estimates.

## Files and checks

- `data/results.csv`: all canonical observations with source sheet/row, completion, ambiguity, and core/variant flags.
- `data/allresults.csv` and `data/reconciliation.csv`: the combined sheet and its observation-level comparison with the reported sheets.
- `data/paired_results.csv`, `coverage.csv`, `gaps_by_depth.csv`, `metric_gap_summary.csv`, `cross_dataset_matched_gaps.csv`, `collisions.csv`, `collision_associations.csv`: numerical figure inputs and summaries.
- `data/efficiency.csv` and `data/efficiency_summary.csv`: individual records and separately checked summaries.
- `data/workbook_cells.json`: every occupied cell, including titles, side notes, and cell comments; `sheet_inventory.csv`: all sheet dimensions.
- `data/literature.csv` and `literature.md`: every qualitative reference.
- `audit.json`: workbook checksum, counts, excluded duplicate observations, and validation checks. `manifest.json`: dependency versions, figure captions, and generated artifact checksums.

The build fails on unresolved shared-sheet conflicts, partially populated metric rows, invalid percentage ranges, non-monotone rank metrics, NDCG greater than HR, duplicate core/efficiency configurations, inconsistent collision values, or mismatched efficiency counts, GPU-hours, utilization, or energy summaries. It checks per-run GPU-hours against wall time × GPU count and validates every emitted PNG/PDF and the combined PDF page count.
