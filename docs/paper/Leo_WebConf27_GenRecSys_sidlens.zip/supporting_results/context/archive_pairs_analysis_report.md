# Next-2-item prediction analysis

Dataset: Amazon Reviews 2014, `Industrial_and_Scientific`, 3,105 items, 3,452
test sequences. Codebook 256 throughout unless stated.

Regenerate from the repository root:

```bash
.conda/bin/python scripts/diagrams/two_item/make_all.py
```

## The metric

Both paradigms score a predicted pair with partial credit: both items correct =
1.0, exactly one correct = 0.5, neither = 0.0. HR@k is the best relevance among
the top k candidate pairs and NDCG@k discounts that best relevance by the rank
it appeared at, with IDCG fixed at 1.0. HR@k is therefore a **graded** quantity,
not a hit count — a run reporting HR@10 = 9.4 is mostly counting half credits.

Re-scoring the raw autoregressive beams reproduces the published graded HR@10
to within **0.004 pp** across all ten runs, which is what licenses the
per-example decompositions in figures 5-9.

## Plotting implementation

- Matplotlib with the non-interactive `Agg` backend; Pandas/NumPy prepare the
  tables and SciPy computes the reported statistics. No browser charting or
  image-generation tool is involved.
- Figure-level titles are omitted from the image files; panel titles, axes,
  legends, and the report caption carry the context.
- 400-dpi PNG plus vector PDF for every figure.

## Coverage

- Paired grid: 3 tokenizers × 3 SID depths × 2 generator paradigms = 18 cells,
  of which **16 are complete**. RQ-KMeans 3-digit DiffGRM was still training
  when these tables were built (figure 11 draws it faintly); MQ 3-digit DiffGRM
  has not been started. Paired-difference statements therefore rest on the
  **7 configurations** where both paradigms finished.
- One codebook-512 run exists (MQ, 3 digits, autoregressive) and appears only in
  figure 13.
- Per-example beams exist for the **autoregressive runs only**. The DiffGRM logs
  record aggregate metrics, so figures 5-9 are one-sided by necessity.

## Main findings

1. **The pair task costs about a quarter of the single-item score.** Pair HR@10
   is **61-90%** of the same configuration's next-1-item HR@10, mean **74%**
   across the 16 completed cells. No configuration escapes the loss. (fig03)

2. **The two paradigms trade places as the cut-off grows.** Averaged over the 7
   paired cells, DiffGRM − Qwen2.5-1.5B pair HR is **+0.94 pp at k = 3**,
   **+0.05 at k = 5**, and **−1.49 at k = 10**. Neither end is significant at
   n = 7 (exact Wilcoxon p = .156 and p = .078), so read this as a consistent
   direction, not an established effect. (fig02)

3. **The mechanism behind that crossover is candidate diversity.** The
   autoregressive runs grow their pair HR by a factor of **1.33-1.83** going
   from k = 3 to k = 10 (mean 1.58); the DiffGRM runs grow by only
   **1.04-1.28** (mean 1.20). DiffGRM's later candidates add almost nothing.
   (fig04)

4. **The second slot is roughly 2-3× harder than the first.** The true next item
   is recovered in the top 10 for **13.0-22.6%** of examples; the item after
   next for only **5.7-10.0%** — a ratio of **1.9× to 3.2×**. (fig05)

5. **Getting both items is rare, and the order is close to a coin flip.** An
   exact ordered pair appears in the top 10 for **1.8-2.9%** of examples. Of
   every retrieval that recovered both items as a candidate pair, **34-51%**
   (median 48%) had them in the wrong order — scoring 0.5 instead of 1.0. Pair
   ordering is close to unlearned. (fig07)

6. **Asking for two items does not damage the first prediction.** Slot-1
   recovery in the pair model matches the dedicated next-1-item model, median
   difference **+0.20 pp** (range −1.83 to +6.55, n = 27 configuration × cut-off
   points). The bottleneck is the second slot, not degraded single-item
   modelling. The two tasks score different test subsets (3,452 vs 3,681
   sequences), so this is an alignment check, not a controlled comparison.
   (fig06)

7. **The collision/performance association reappears on the pair task.**
   Collision rate measured on these runs versus pair HR@10 is Spearman
   **ρ = +0.883 (p = .002, n = 9)**, over a collision range of **0.35-29.15%**.
   Codebook utilization is weaker at ρ = +0.54 (p = .131). This replicates the
   next-item finding on a new task and, again, is an association: tokenizer and
   depth jointly set both axes. Figure 11(c) shows the mechanism candidate — the
   highest-collision configuration also posts the most generous validation
   curve. (fig10, fig11)

8. **Constrained decoding returns a short list, and that does not hurt.** After
   illegal-sequence filtering the decoder scores **17.7-19.6** of the 20
   requested pairs (**74-92%** of examples keep a full list). Yield correlates
   *negatively* with the score (ρ = −0.78, n = 9), which tracks the tokenizer,
   not the yield. Every returned pair carries a **distinct** first item, so the
   decoder never spends two slots on two continuations of the same next item —
   a structural cap on the exact-pair rate. (fig09)

9. **The rank-1 guess is usually not even semantically close.** Its first item
   shares **no leading SID digit** with the true next item for **75-92%** of
   examples. Near-misses are not the dominant failure mode; the model is
   frequently in a different region of the semantic-ID space entirely. (fig08)

10. **Confidence-ordered unmasking is nearly free of effect on pairs.** Across
    the 7 completed DiffGRM runs, confidence ordering moves pair NDCG@10 by
    **|Δ| ≤ 0.17 pp in 6 of 7 cases**. The exception is RQ-VAE 4-digit
    (**+1.44 pp** NDCG@10, +1.31 pp HR@3). On this task the decoding order is
    not carrying the result. (fig12)

11. **Cost is uniform and uninformative.** The autoregressive runs take
    **1.45-1.96 wall-clock hours** end to end, of which constrained-decoding
    evaluation is **39-50%**. Total time versus pair NDCG@10 is ρ = −0.30
    (p = .40, n = 10) — within this narrow envelope, time bought nothing.
    (fig13)

## Interpretation limits

- **Associations, not causal estimates.** Tokenizer, depth, and codebook jointly
  determine collision, utilization, beam yield, and reported performance.
- **One run per cell, no seeds.** Every p-value here describes ordering across
  design cells; none is an experimental error bar.
- **n = 7 for every paired paradigm claim.** Finding 2's direction is consistent
  but neither tail reaches significance.
- **Figures 5-9 are autoregressive-only.** They describe how the Qwen pair model
  earns its score and must not be read as claims about DiffGRM, whose logs carry
  no per-example beams.
- **Figure 6 compares different test subsets** (3,452 pair sequences vs 3,681
  single-item sequences), because a pair example requires two held-out items.
- **Figure 11 panels are not mutually comparable in absolute value**: (a) is
  next-token cross-entropy on a held-out split, (b) is DiffGRM's masked-token
  training objective, and the two run on different epoch budgets and hardware
  allocations. Panel (c) is measured on the validation split.
- **Wall time in figure 13 comes from a shared cluster**, so runs are not
  guaranteed identical hardware, and it covers autoregressive runs only — the
  DiffGRM logs record no comparable end-to-end budget. It is not an
  AR-versus-DiffGRM efficiency comparison.
- **Collision here is measured on the two-item runs themselves**
  (`(items − distinct full SIDs) / items`), not taken from the earlier
  collision workbook, whose codebook-256 values were flagged as stale.

## Figures

See [`README.md`](README.md) for the figure index; source tables are in
[`data/`](data/).
