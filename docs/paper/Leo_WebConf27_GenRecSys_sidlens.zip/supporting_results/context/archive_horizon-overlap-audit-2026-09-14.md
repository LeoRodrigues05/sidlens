# DiffGRM horizon-two overlap audit — 14 September 2026

The overlap has existed throughout the tracked history of `DiffGRM_new`. It is
a material evaluation-design error. Historical next-two results should be
marked **provisional legacy-protocol results**, rather than evidence from an
independent held-out target horizon. This finding does not by itself invalidate
the static SID/codebook analyses or establish that next-item runs have this bug.

## History and observed runs

- Commit `baccc0e4afa7bfc8626e795e110fd90c91088483`, authored 3 August 2026,
  introduced the two-item tree. Its `genrec/dataset.py` already used `seq` for
  test and `seq[:-1]` for validation, while taking the last two events as labels.
  Both sliding and non-sliding branches had the overlap.
- Commit `a165f659c47eb209ef1a0506c1d4abc665485876`, 13 September 2026, added
  `strict_min_history_disjoint_v2`. It corrected the training minimum history
  and kept training labels outside validation/test labels. It **did not** move
  validation away from the test target horizon. Its name must not be interpreted
  as a guarantee of validation/test disjointness.
- On 14 September, all **25 named Industrial next-two logs** under
  `/l/users/leo.rodrigues/onediffrec/diffgrm_2item/Industrial_and_Scientific`
  reported tokenizing **17,896 train, 6,297 validation and 6,297 test examples**.
  These exactly match replay of the original split against the archived cache.
  Twenty-three include completed test results; two are incomplete. This is
  direct run evidence for the legacy protocol, although old jobs lack the full
  executable source fingerprints now recorded for future runs.
- For example, `MQ_3codebook_128.txt` reports `Best epoch: 67, Best val score:
  0.1886`. The model trainer selects a checkpoint using validation score,
  applies validation-based early stopping, and reloads the selected checkpoint
  before final test. The overlapping validation feedback was actually used.

The tracked-source history can be inspected with:

```bash
git log --all -- DiffGRM_new/genrec/dataset.py
git show baccc0e4:DiffGRM_new/genrec/dataset.py
git show a165f659 -- DiffGRM_new/genrec/dataset.py
```

The audited Industrial cache is
`unused/local-only/generated-caches/DiffGRM_new-cache/AmazonReviews2014/Industrial_and_Scientific/processed/all_item_seqs.json`.
Its SHA-256 is
`b7627c49db42165f94c88e51cbc9ff82d363c57bf98503c87e2343f77220f6f8`:
6,297 real users and 43,102 events. The model's logged 6,298 user count includes
its padding identity.

## Exact failure and severity

For zero-based event positions `0…L-1` in one user's history:

| Protocol | Last training target positions (when eligible and uncapped) | Validation targets | Test targets |
|---|---|---|---|
| `legacy_sliding_v1` | `L-4, L-3` | `L-3, L-2` | `L-2, L-1` |
| `strict_min_history_disjoint_v2` | `L-5, L-4` | `L-3, L-2` | `L-2, L-1` |
| `disjoint_horizon_v3` | `L-6, L-5` | `L-4, L-3` | `L-2, L-1` |

Legacy training can supervise the first validation event; both old protocols
then reuse one of the two test events as a validation target. No final test
event position is directly an SGD label under these splits. However, model
selection and stopping are informed by an event subsequently scored on test.
That violates the intended independent target holdout and can bias reported
performance or variant ordering. The magnitude and direction cannot be inferred
from the overlap alone; a corrected rerun is required to measure the effect.

The overlap is in **user/event positions**, independently of SID collisions or
repeat purchases. Observing an earlier validation event in the *history* of a
later test prediction is valid rolling-origin evaluation. Reusing that event
as a test *target* is the error addressed here.

Replaying all three split implementations with horizon 2, minimum history 2,
maximum history 50 and sliding training gives:

| Protocol | Train examples / users | Validation examples | Test examples | Shared train/val target events | Shared val/test target events |
|---|---:|---:|---:|---:|---:|
| Legacy v1 | 17,896 / 6,297 | 6,297 | 6,297 | 6,295 | 6,297 |
| Strict v2 | 7,978 / 2,235 | 6,297 | 6,297 | 0 | 6,297 |
| Disjoint horizon v3 | 5,758 / 1,459 | 3,624 | 6,297 | 0 | 0 |

Train/test target overlap is zero in all three. Legacy has 6,297 training
windows with only one history event despite a configured minimum of two. The
two users without legacy train/validation overlap have long histories affected
by the old prefix-window cap. V3 keeps all eligible origins and caps history
at the latest 50 events, so it also changes long-user exposure relative to the
old prefix cap. The smaller v3 validation/training population is an explicit
cost of reserving two complete target horizons on short sequences. It must be
reported; it must not be silently mixed into historical aggregates.

## Repair and what needs rerunning

The new `split_protocol=disjoint_horizon_v3` is an explicit versioned protocol;
legacy v1 and strict v2 remain available unchanged for reproduction.
[The dependency-free splitter](../../DiffGRM_new/genrec/horizon_split.py) is
shared by canonical cohort preparation and the two-item dataset loader. It
supports any positive horizon, with tests for next-item and next-two. Each
output includes original history and target event positions for auditing.

For horizon `h`, it reserves `[L-h,L)` for test and `[L-2h,L-h)` for validation.
Training target blocks end no later than `L-2h`; all origins satisfying the
minimum history are included in sliding mode. Every split requires at least
`min_hist_len` observed events; short users can therefore be test-only.
Histories use the latest `max_hist_len` events at each origin. When calling
the DiffGRM model directly, keep its `max_history_len` at least the splitter's
minimum and normally equal to `max_hist_len`.

**Rerunning metrics or decoding on a selected legacy checkpoint does not undo
selection leakage.** Moving validation earlier also does not repair old
weights: those earlier targets were already trained on under the old split.
Fresh training and checkpoint selection under v3 are needed for the principal
held-out comparison. Preserve old results in a separate legacy table; rerun
matched Industrial/Office anchors and expand the grid once validated. New
decoder/metric evaluations on old weights are useful diagnostic experiments
but must retain the legacy split provenance.

This fix establishes event-disjoint chronological splits within each user. It
does not make a global calendar-time split, prevent the same product appearing
for different users, or align AR/Diff automatically unless both consume the
shared cohort protocol. These are separate choices in the broader comparison.

## Verification

`tests/test_diffgrm_two_item_split.py` has 12 passing tests, including preserved
legacy/v2 outputs, explicit old validation/test overlap, v3 split routing,
pairwise target-event disjointness over horizons 1/2/3 and lengths 0–100,
minimum-history eligibility, repeated item identities, sliding/non-sliding
training, and correct latest-history capping without dropping later origins.
The full Industrial cache was replayed to produce the counts above. No training
jobs were submitted or stopped during this audit. A read-only `squeue` check
for `leo.rodrigues` returned no active jobs at audit time.
