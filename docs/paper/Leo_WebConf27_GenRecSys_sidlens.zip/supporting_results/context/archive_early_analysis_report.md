# Collision-rate and reported-performance analysis

Source workbook: `CollisionRates_GenRec_Paradigms.xlsx`
SHA-256: `bb4c11c1ac03f8507d4039bd1faadfd9d3b266858bcd79bde531e323a206b5d1`

Regenerate from the repository root:

```bash
.conda/bin/python scripts/diagrams/new/make_all.py
```

## Plotting implementation

- All plots are generated in Python with **Matplotlib 3.11.1** using its non-interactive `Agg` backend; no browser charting or image-generation tool is involved.
- Pandas and NumPy prepare the tables, SciPy computes the reported statistics, OpenPyXL reads the workbook, pypdf extracts the Office table, and the W&B protobuf reader recovers training telemetry.
- Figure-level titles are intentionally omitted from the image files; panel titles, axes, legends, and the paper/report caption carry the context.

## Scope and data treatment

- Collision grid: **54 rows** = 2 datasets × 3 tokenizers × 3 depths × 3 codebooks.
- Populated performance results: **59 rows**. The balanced analysis uses **54 core rows** = 27 SID configurations × 2 generator paradigms; **5 additional model/training-ablation rows** are isolated in figure 7.
- Office performance comparison: **18 rows** = 3 tokenizers × 3 depths × 2 paradigms at codebook 256, extracted from research-notes PDF pages 1–3 (SHA-256 `5f930d026f4aa1ae66d2359e9f33a0425224ac51e77337d824808bbe2fd44d30`).
- Training-resource comparison: **18 completed Industrial next-item SFT runs** = 3 SID tokenizers × 3 depths × 2 codebook sizes (128 and 512), all on 4 × NVIDIA A100-SXM4-40GB GPUs. Each retained evaluation contains 3,681 examples and uses 50-beam constrained decoding.
- Every collision/performance association uses the **27 SID configurations** as the statistical unit by averaging the paired paradigms. This avoids counting the same collision value twice.
- The performance section does not explicitly name its dataset. It is treated as **Industrial by workbook placement**, which is an inference.
- Collision is `(N − unique full SIDs) / N`: the count is excess SID assignments, not the number of all items that belong to collided groups.

## Main findings

1. **Collision rate and reported ranking metrics move together.** Across the 27 paired-configuration means, collision versus HR@10 has Spearman ρ = **0.872** (p < .001), and collision versus NDCG@10 has ρ = **0.851** (p < .001). Across all six reported metrics, ρ spans **0.849–0.877**.

2. **The result survives the workbook's artifact warning.** Excluding every codebook-256 collision value leaves n = 18 configurations and HR@10 ρ = **0.877** (p < .001).

3. **The pooled relationship is not just a tokenizer-level contrast, but it is heterogeneous.** Within-tokenizer HR@10 associations are RQ-KMeans **+0.900**, MQ **+0.833**, and RQ-VAE **-0.166**. RQ-VAE only spans 0.35–1.16% collision, so it provides little range for this relationship.

4. **Collision ordering transfers across datasets.** Industrial versus Office collision has ρ = **0.946** (p < .001). The main exception is RQ-KMeans, 5 digits × 512: 0.3543% on Industrial versus 5.4476% on Office (**15.4×**).

5. **Longer SIDs expose a paradigm gap.** Mean diffusion-family minus autoregressive HR@10 is **-0.17** at 3 digits, **-1.07** at 4, and **-3.76** at 5. All 9 five-digit cells are negative (two-sided exact Wilcoxon p = 0.0039 across configuration cells).

6. **The six performance metrics are nearly redundant.** Their pairwise configuration-level Spearman correlations span **0.968–0.996**, supporting HR@10 and NDCG@10 as compact headline views.
7. **The Industrial paradigm-depth result does not transfer to Office at codebook 256.** Mean diffusion-family minus autoregressive HR@10 is **+1.28/+0.03/-3.34** on Industrial at depths 3/4/5, but **+6.52/+7.63/+5.79** on Office. Row-level HR@10 rank agreement is ρ = **+0.040** (p = .874; n = 18).
8. **The available SFT runs occupy a fairly narrow compute envelope, but wall time still varies.** Hugging Face estimated training compute spans **1.207–1.364 EFLOP**, while sweep wall time spans **3.85–4.97 GPU-hours** and sampled GPU energy spans **1.13–1.38 kWh**. Measured end-to-end evaluation time is **166–214 s** (**45.1–58.1 ms/example**). **4 of 18** configurations are non-dominated on the observed NDCG@10 versus total training-plus-evaluation allocation trade-off.

## Figures

| Figure | Question answered |
|---|---|
| [`fig01_collision_design_space`](fig01_collision_design_space.png) | How do tokenizer, depth, codebook, and dataset relate to collision? |
| [`fig02_cross_dataset_collision`](fig02_cross_dataset_collision.png) | Does a configuration's collision behavior transfer across datasets? |
| [`fig03_collision_vs_reported_metrics`](fig03_collision_vs_reported_metrics.png) | How strongly do collision and headline metrics co-vary? |
| [`fig04_within_tokenizer_association`](fig04_within_tokenizer_association.png) | Does the relationship persist within each tokenizer? |
| [`fig05_metric_robustness`](fig05_metric_robustness.png) | Is the association consistent across metrics, paradigms, and artifact sensitivity? |
| [`fig06_paradigm_gap_by_depth`](fig06_paradigm_gap_by_depth.png) | How does the paired generator-paradigm gap change with SID depth? |
| [`fig07_model_training_ablation`](fig07_model_training_ablation.png) | What model/training comparisons are available at the shared nominal setting? |
| [`fig08_full_configuration_grid`](fig08_full_configuration_grid.png) | What are the aligned values for every core SID configuration? |
| [`fig09_factorial_main_effects`](fig09_factorial_main_effects.png) | What are the balanced marginal effects of tokenizer, depth, and codebook? |
| [`fig10_cross_dataset_paradigm_gap`](fig10_cross_dataset_paradigm_gap.png) | Does the generator-paradigm gap transfer from Industrial to Office? |
| [`fig11_training_compute_resources`](fig11_training_compute_resources.png) | How do estimated training compute, measured evaluation time, and accuracy trade off? |
| [`fig12_sid_depth_tradeoff`](fig12_sid_depth_tradeoff.png) | How does SID depth jointly affect collision, the paired model gap, and measured evaluation cost? |

Every Matplotlib figure is emitted as both a 400-dpi PNG and a vector PDF. Tidy source and derived tables are under `data/` beside this report.

## Interpretation limits

- These are **associations, not causal estimates** of collision's effect. Tokenizer, depth, and codebook jointly determine collision and also co-vary with reported performance.
- There is one value per configuration and no seed/run variance. Configuration-cell p-values describe ordering across design cells; they are not experimental error bars or training uncertainty.
- Industrial codebook-256 collision values are labeled “old artifact/from previous runs,” and every Office collision value is labeled as a previous run. Sensitivity results therefore exclude codebook 256 where possible.
- The analysis maps collision-table `MQ` to performance-table `Parallel SID`; this is inferred from the layout and naming.
- Rows labeled `Mask Diffusion` at codebooks 128/512 and `DiffGRM` at 256 are grouped as a **diffusion-family paradigm**. That grouping does not establish that the implementations are identical.
- The Office codebook-256 heading is explicit for RQ-VAE. Its continuation through the RQ-KMeans and Parallel-SID subtables is a section-layout inference, recorded row-by-row in `office_core_codebook256.csv`.
- Resource data cover autoregressive SFT only and omit codebook 256; they must not be used as a direct AR-versus-DiffGRM efficiency comparison. `total_flos` is the Hugging Face analytical estimate (6 × padded tokens × non-embedding parameters), not a hardware-counter measurement. Energy integrates sampled training-GPU power and excludes CPUs, cooling, evaluation, and PUE. Existing evaluation artifacts record end-to-end wall time but no inference FLOP counter or inference-only telemetry, so inference FLOPs cannot be reconstructed without a profiled rerun.
- Metric units appear to be percentage points, but the workbook does not explicitly state units.
- A synthetic “collision-corrected leaderboard” is intentionally omitted: the design variables are structurally collinear, so such counterfactual rankings would be assumption-heavy without item-level predictions or controlled reruns.
