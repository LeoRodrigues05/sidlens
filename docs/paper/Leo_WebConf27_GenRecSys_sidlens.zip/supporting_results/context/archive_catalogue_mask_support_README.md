# Catalogue-only mask-support pilot

The script validates all 27 cached item-token mappings against SidLens's canonical `SidTable` `.sem_ids` loader, using the canonical ASIN-to-item-ID mapping. All 27 agree exactly. It excludes the verified all-zero PAD row (index 0) from each 3106-row mapping, leaving 3105 catalogue items. No models or histories are used.

It enumerates all 504 visible-digit subsets across the 27 variants, including empty/full subsets, and writes 135 summaries by visible count. Every input mapping and canonical SID file is hashed. Source-bound masking observations and transcript hashes are separate from the combinatorial results.

| Variant | Visible digits | Item uniquely identified | Full SID determined | Masked tokens deterministic |
|---|---:|---:|---:|---:|
| RQ-VAE 4x128 | 1 of4 | 0.00% | 0.00% | 0.027% |
| RQ-VAE 4x128 | 2 of4 | 52.88% | 53.23% | 56.46% |
| RQ-VAE 4x128 | 3 of4 | 91.87% | 92.54% | 92.54% |
| RQ-KMeans 3x128 | 1 of3 | 0.99% | 1.76% | 2.51% |
| RQ-KMeans 3x128 | 2 of3 | 18.09% | 33.08% | 33.08% |

All table entries use **uniform catalogue-item weighting and uniform averaging over visible subsets of the stated size**. They are not training-loss percentages or actual guided-policy averages. An item is unique only when its visible coordinates identify one catalogue identity. A full SID can be determined even when several colliding item identities remain. With every digit visible, only55.20% of RQ-KMeans3x128 items are in singleton buckets, whereas every full SID is of course determined.

The corresponding distinct-SID-uniform final-masked-digit determinism is92.56% for RQ-VAE4x128 and32.41% for RQ-KMeans3x128; this weighting gives one vote per distinct full code instead of one per catalogue item.

Subset identity matters. In RQ-VAE4x128, revealing digits[0,1] makes28.82% of the two remaining token targets deterministic; revealing[2,3] makes80.03% deterministic. Revealing[1,2,3] makes the remaining first digit deterministic for99.55% of catalogue items. Digit indices are zero-based. Thus a low-mask prediction can be a catalogue-completion task even when the hidden digit is the nominally 'coarse' first digit.

## What this establishes

Many lightly masked targets, especially in the retained RQ-VAE4x128 condition, have no remaining code uncertainty once the visible target digits and catalogue are given. This establishes a plausible opportunity for history-independent completion, not evidence that the network actually uses that solution, ignores history, or learns a harmful shortcut. The high terminal percentage cannot be called a majority of training supervision: masked counts have different loss weights and actual targets/subsets are not uniform.

The next decisive inference test should select the *same number of visible digits* but compare deterministic versus ambiguous catalogue completions. Hold the visible target and mask fixed; replace or patch history using valid matched donors; measure target-logit and candidate-ranking changes. Frequency/support matching is needed. A model-dependent lack of sensitivity can be correct behaviour in a deterministic catalogue state, so a harm claim additionally needs effects on ambiguous/all-mask decisions and a controlled training intervention.

## Separate source-bound masking-coverage finding

The retained next1 registry has20 trained entries, all guided/least/refreshfalse. Seven depth3 entries record3 steps; the other13 depth4/5 entries record4 steps. All seven retained depth5 transcripts explicitly print `GUIDED: steps=4`. No retained next1 transcript records a schedule event.

The frozen model hard-caps guided steps at4 (`vendor/diffgrm/genrec/models/DIFF_GRM/model.py:260-263`). Its guided constructor creates one supervised view with t masked positions for each t=1,...,guided_steps (`:701-712`), with ground-truth codes at the other positions. Hence the recorded depth5 condition has no **supervised fully masked** view in this path. It does query an all-masked input without gradients to choose an order; saying it never sees an all-masked input would be wrong.

The mutually exclusive guided branch feeds only those views into token-averaged masked cross-entropy (`:857-874`). With g steps, masked-count t contributes t/[g(g+1)/2] of token weight, independent of which subset was chosen. The default schedule is disabled (`config.yaml:139-140`), the frozen launcher contains no schedule override, and the trainer activates a different stage only when enabled (`trainer.py:132-138`). No additional supervised all-mask term was found in this forward path. The script records configurations, transcript evidence and source hashes.

This is a **coverage confound and required control**, not evidence that catalogue completion harms learning. Any future depth5/ambiguity-aware comparison should first match full-mask coverage and effective token/example budgets. Historical per-example mask frequencies, training gradients and checkpoint trajectories are not available here.

## Reproduction and files

Run:

```bash
/l/users/leo.rodrigues/sidlens/venv/bin/python sidlensreview/evidence/review-2026-09-10/novelty/catalogue_mask_support.py
```

- `catalogue_mask_support.py`: deterministic, read-only analysis of frozen inputs.
- `catalogue_mask_support.json`: definitions, limitations, hashes, source audit and complete results.
- `catalogue_mask_support_subsets.csv`:504 actual-subset rows.
- `catalogue_mask_support_counts.csv`:135 visible-count rows, with subset mean/min/max.
