# SidLens additions to the WWW'27 draft (2026-09-25)

This revision adds the completed SidLens experiments to the draft. Every
number traces to a packaged CSV under `data/`, pinned by sha256 in
`data/sidlens_manifest.json`. Numbers quoted only in the text are listed with
their source file and hash in `data/sidlens_claims.csv`.

## What changed

| File | Change |
|---|---|
| `sections/abstract.tex` | Adds controlled re-decoding and the map analysis to the evidence list, plus the beam-dependence result. |
| `sections/introduction.tex` | Four components instead of three; the evidence-status paragraph lists the new completed results. |
| `sections/preliminaries.tex` | New subsection *Reveal Orders and Beam Search* (`sec:reveal`): fixed and confidence policies, path-keeping beams. |
| `sections/experimental_setup.tex` | AR evaluation-versus-training prompt wording. New paragraphs *Controlled decoding protocol* and *Identifier-map analyses*. |
| `sections/results.tex` | Depth-5 short-list confound; next-two slot association; AR next-item prefix errors; exact CCE reproduction and collision strata. New subsections *Controlled Re-decoding of Retained Diff Checkpoints* (`sec:decoding-results`, Table `tab:decoding`, Figures `fig:decoding`, `fig:fixed-orders`) and *What the Identifier Maps Encode* (`sec:maps`, Figure `fig:digits`, RQ-KMeans 5x512 provenance note). Pending list updated. |
| `sections/discussion.tex`, `conclusion.tex` | *Search is part of the system*; added limits; search budgets in the conclusion. |
| `sections/appendix_results.tex` | Not compiled. The same stale "atlas not recovered" sentence is replaced. |
| `tools/plot_sidlens.py` | New. Draws the three `figures/pub_sidlens_*.pdf` from the packaged CSVs, with `plot_paper.py`'s style, colours and 8-pt/canvas checks. |
| `tools/prepare.py` | Adds `tools/plot_sidlens.py` to the packaging allowlist. |
| `data/sidlens_*` | New packaged tables, manifest and claims ledger. |

## Regenerate

```bash
# in the SidLens repo (needs $SIDLENS_WORK): rebuild data/ from derived results
python experiments/paper_www27/export_paper_data.py --out /tmp/www27_data
# in this project: redraw the figures from data/
python3 tools/plot_sidlens.py
```

## Definitions to keep straight

- The paper's **collision rate** is the share of items in non-singleton SID
  groups. SidLens's semantic-mapping `collision_rate` is **duplicate excess**
  (1 - unique/items). `data/sidlens_map_collisions.csv` has both.
- **Seed-42** means the archived fixed reveal permutation. **Archived decoder**
  means the historical confidence decoder (greedy last digit). The *shared
  search* conditions differ only in which position may be revealed next.
- Decoding intervals are paired-user bootstraps (2,000 draws). They exclude
  training-seed variation, and the checkpoints were selected with
  confidence-guided validation.

## Open items for the authors

- Page count grew from 11 to 15, including references.
- Related work does not yet cite mapping-level SID diagnostics (e.g.
  SIDInspector) or the SID-design reproducibility study. Add verified
  bibliography entries before citing them.
- The RQ-KMeans 5x512 map needs a provenance note from whoever built it.
