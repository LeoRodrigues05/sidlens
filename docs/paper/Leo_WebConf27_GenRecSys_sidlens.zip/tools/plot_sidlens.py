#!/usr/bin/env python3
"""Draw the three SidLens figures from packaged, hash-pinned CSVs.

From any directory: python3 paper/www2027/tools/plot_sidlens.py
Inputs are data/sidlens_*.csv, verified against data/sidlens_manifest.json
(written by SidLens experiments/paper_www27/export_paper_data.py). Style,
colours, the 8-point minimum and the print-canvas check are shared with
tools/plot_paper.py. No raw interactions, checkpoints or inference needed.
--preview-dir optionally writes 180-dpi PNG previews.
"""

import argparse
import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import fmean

sys.path.insert(0, str(Path(__file__).resolve().parent))
import plot_paper as P  # noqa: E402  (configure(), colours, dot_handle)

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402
from matplotlib.text import Text  # noqa: E402

PROJECT = P.PROJECT
DATA = PROJECT / "data"
QCOLOR = {"rqvae": P.BLUE, "rqkmeans": P.ORANGE, "MQ": "#8A5DA2"}
QNAME = {"rqvae": "RQ-VAE", "rqkmeans": "RQ-KMeans", "MQ": "MQ"}
QORDER = ["rqvae", "rqkmeans", "MQ"]


def read_sources():
    manifest = json.loads((DATA / "sidlens_manifest.json").read_text())
    tables = {}
    for key, source in manifest["sources"].items():
        path = DATA / source["packaged_csv"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != source["packaged_sha256"]:
            raise ValueError(f"Packaged SidLens input changed: {path.name}")
        with path.open(newline="") as handle:
            tables[key] = list(csv.DictReader(handle))
        assert len(tables[key]) == source["rows"], key
    return tables


def finish(fig, name, output_dir, preview_dir):
    """plot_paper.finish's checks, with this script named as the creator."""
    fig.canvas.draw()
    small = [t.get_fontsize() for t in fig.findobj(Text)
             if t.get_visible() and t.get_text() and t.get_fontsize() < 8]
    if small:
        raise ValueError(f"Font below 8 pt in {name}: {small}")
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if (box.x0 < -.5 or box.y0 < -.5 or box.x1 > fig.bbox.x1 + .5
                or box.y1 > fig.bbox.y1 + .5):
            raise ValueError(f"Text outside print canvas in {name}: {text.get_text()!r}")
    path = output_dir / f"pub_{name}.pdf"
    fig.savefig(path, metadata={"Creator": "tools/plot_sidlens.py",
                               "CreationDate": None, "ModDate": None})
    if preview_dir:
        preview_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(preview_dir / f"pub_{name}.png", dpi=180)
    print(f"{path.name}: {fig.get_figwidth():.2f} × {fig.get_figheight():.2f} in; font ≥8 pt")
    plt.close(fig)


def decoding_budget(cells, contrasts):
    """Reveal policy x beam x depth on 18 retained checkpoints (6,297 users each)."""
    assert len(cells) == 108
    by = defaultdict(dict)
    for r in cells:
        by[(r["checkpoint"], int(r["beam"]))][r["policy"]] = r
    # The primary contrast in the packaged summary must equal the cell mean.
    primary = [c for c in contrasts if c["experiment"] == "matched_beam_18_cells"
               and c["outcome"] == "sid_hit@10"]
    for c in primary:
        diffs = [float(v["confidence"]["sid_hit10_pct"]) - float(v["fixed"]["sid_hit10_pct"])
                 for (ck, b), v in by.items() if b == int(c["beam"])]
        assert len(diffs) == 18 and abs(fmean(diffs) - float(c["difference_pp"])) < 1e-9

    fig, axes = plt.subplots(1, 3, figsize=(6.9, 3.0))
    fig.subplots_adjust(left=0.075, right=0.99, bottom=0.31, top=0.8, wspace=0.42)
    depths = [3, 4, 5]

    # (a) confidence minus fixed, per cell and mean
    ax = axes[0]
    for beam, filled, ls in ((64, True, "-"), (256, False, "--")):
        means = []
        for d in depths:
            vals = []
            for (ck, b), v in by.items():
                c = v["confidence"]
                if b != beam or int(c["depth"]) != d:
                    continue
                diff = float(c["sid_hit10_pct"]) - float(v["fixed"]["sid_hit10_pct"])
                vals.append(diff)
                q = c["quantizer"]
                x = d + (QORDER.index(q) - 1) * .07 + (-.2 if beam == 64 else .2)
                color = QCOLOR[q]
                ax.scatter(x, diff, s=13, zorder=3, linewidth=.7,
                           facecolor=color if filled else "white", edgecolor=color)
            means.append(fmean(vals))
        ax.plot([d + (-.2 if beam == 64 else .2) for d in depths], means, color=P.INK,
                linestyle=ls, marker="D", markersize=3, linewidth=1.1, zorder=4)
    ax.axhline(0, color="#7C8794", linewidth=.7)
    ax.set_xticks(depths)
    ax.set_xlim(2.5, 5.5)
    ax.set_xlabel("SID depth")
    ax.set_ylabel("Confidence − fixed (pp)")
    ax.set_title("(a) SID Hit@10 difference")
    ax.grid(axis="y")

    # (b) composition of the final beam at B=64
    ax = axes[1]
    width = .34
    for i, d in enumerate(depths):
        for j, policy in enumerate(("confidence", "fixed")):
            sel = [v[policy] for (ck, b), v in by.items() if b == 64 and int(v[policy]["depth"]) == d]
            dup = 100 * fmean(float(r["duplicate_path_share"]) for r in sel)
            inv = 100 * fmean(float(r["invalid_path_share"]) for r in sel)
            legal = 100 - dup - inv
            x = i + (j - .5) * (width + .04)
            ax.bar(x, legal, width, color=P.INK)
            ax.bar(x, inv, width, bottom=legal, color=P.GRAY)
            ax.bar(x, dup, width, bottom=legal + inv, color=P.TEAL)
    ticks = [i + (j - .5) * (width + .04) for i in range(3) for j in range(2)]
    ax.set_xticks(ticks, ["C", "F"] * 3)
    for i, d in enumerate(depths):
        ax.text(i, -0.2, f"depth {d}", transform=ax.get_xaxis_transform(),
                ha="center", va="top", fontsize=8)
    ax.tick_params(axis="x", length=0)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Final paths (%)")
    ax.set_title("(b) Final beam, B=64")

    # (c) users receiving ten distinct legal SIDs
    ax = axes[2]
    series = (("confidence", 64, P.INK, "o", "-", "Conf., 64"),
              ("confidence", 256, P.INK, "s", "--", "Conf., 256"),
              ("legacy_confidence", 256, P.TEAL, "^", "-", "Archived, 256"),
              ("fixed", 64, "#7C8794", "v", ":", "Fixed, 64"))
    for policy, beam, color, marker, ls, label in series:
        ys = [fmean(float(v[policy]["users_with_ten_pct"]) for (ck, b), v in by.items()
                    if b == beam and int(v[policy]["depth"]) == d) for d in depths]
        ax.plot(depths, ys, color=color, marker=marker, markersize=3.5, linestyle=ls,
                linewidth=1.1, label=label, markerfacecolor=color if ls != "--" else "white")
    ax.set_xticks(depths)
    ax.set_xlim(2.7, 5.3)
    ax.set_ylim(0, 105)
    ax.set_xlabel("SID depth")
    ax.set_ylabel("Users with 10 SIDs (%)")
    ax.set_title("(c) List coverage")
    ax.grid(axis="y")
    ax.legend(loc="upper center", bbox_to_anchor=(.42, -.27), ncol=2, handlelength=1.8,
              columnspacing=.8, handletextpad=.35)

    handles = [Line2D([], [], color=QCOLOR[q], marker="o", linestyle="none",
                      markersize=4.5, label=QNAME[q]) for q in QORDER]
    handles += [Line2D([], [], color=P.INK, marker="D", markersize=3, label="Mean, B=64"),
                Line2D([], [], color=P.INK, marker="D", markersize=3, linestyle="--",
                       markerfacecolor="white", label="Mean, B=256"),
                Patch(color=P.INK, label="Legal unique"), Patch(color=P.GRAY, label="Invalid"),
                Patch(color=P.TEAL, label="Duplicate")]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, 1.0), ncol=8,
               columnspacing=.8, handlelength=1.3, handletextpad=.35)
    return fig


def fixed_orders(cells, per_cell):
    """Confidence against all six fixed orders on six depth-3 checkpoints."""
    assert len(cells) == 42
    ci = {r["checkpoint"]: r for r in per_cell if r["outcome"] == "sid_hit@10"}
    rows = sorted({r["checkpoint"] for r in cells},
                  key=lambda ck: (QORDER.index(ck.split("-")[2]), int(ck.split("-")[-1])))
    fig, ax = plt.subplots(figsize=(3.33, 2.55))
    fig.subplots_adjust(left=.31, right=.97, bottom=.2, top=.86)
    for y, ck in enumerate(rows):
        part = {r["condition"]: float(r["sid_hit@10_pct"]) for r in cells if r["checkpoint"] == ck}
        fixed = [v for k, v in part.items() if k != "confidence"]
        assert len(fixed) == 6
        mean_fixed = fmean(fixed)
        assert abs(mean_fixed - float(ci[ck]["mean_fixed_pct"])) < 1e-9
        q = ck.split("-")[2]
        ax.hlines(y, min(fixed) - mean_fixed, max(fixed) - mean_fixed, color=P.GRAY, linewidth=1.0)
        ax.scatter([v - mean_fixed for v in fixed], [y] * 6, s=9, color="#7C8794", zorder=3)
        d, lo, hi = (float(ci[ck][k]) for k in ("difference_pp", "ci95_low_pp", "ci95_high_pp"))
        ax.errorbar(d, y, xerr=[[d - lo], [hi - d]], fmt="o", color=QCOLOR[q],
                    markersize=4.5, elinewidth=1.0, capsize=2, zorder=4)
    ax.axvline(0, color=P.INK, linewidth=.8)
    ax.set_xlim(-1.8, 1.5)
    ax.set_xticks([-1.5, -1, -.5, 0, .5, 1], ["−1.5", "−1", "−0.5", "0", "0.5", "1"])
    ax.set_yticks(range(len(rows)),
                  [f"{QNAME[ck.split('-')[2]]} {ck.split('-')[-1]}" for ck in rows])
    ax.set_ylim(len(rows) - .4, -.6)
    ax.set_xlabel("SID Hit@10 − mean fixed (pp)")
    ax.grid(axis="x")
    fig.legend(handles=[P.dot_handle("#7C8794", "o", "Six fixed orders"),
                        Line2D([], [], color=P.INK, marker="o", linestyle="-", markersize=4.5,
                               label="Confidence, 95% CI")],
               loc="upper center", bbox_to_anchor=(.5, 1.0), ncol=2, columnspacing=.9,
               handletextpad=.35)
    return fig


def digit_structure(digits, purity):
    """What each digit position encodes in the three 4x128 maps."""
    sel = [r for r in digits if r["n_codebook"] == "4" and r["codebook_size"] == "128"]
    pur = [r for r in purity if r["n_codebook"] == "4" and r["codebook_size"] == "128"
           and r["field"] == "cat_l1"]
    assert len(sel) == 12 and len(pur) == 12
    fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.45))
    fig.subplots_adjust(left=.075, right=.99, bottom=.19, top=.8, wspace=.36)
    for q in QORDER:
        rows = sorted((r for r in sel if r["quantizer"] == q), key=lambda r: int(r["digit"]))
        x = [int(r["digit"]) for r in rows]
        c = QCOLOR[q]
        axes[0].plot(x, [100 * float(r["standalone_between_share"]) for r in rows],
                     color=c, marker="o", markersize=3.5, linewidth=1.1)
        axes[1].plot(x, [float(r["marginal_ami"]) for r in rows], color=c, marker="o",
                     markersize=3.5, linewidth=1.1)
        cond = [(int(r["digit"]), float(r["conditional_ami"])) for r in rows
                if r["conditional_supported"] == "True" and int(r["digit"]) > 1]
        axes[1].plot([p[0] for p in cond], [p[1] for p in cond], color=c, marker="o",
                     markerfacecolor="white", markersize=3.5, linewidth=1.0, linestyle="--")
        prow = sorted((r for r in pur if r["quantizer"] == q), key=lambda r: int(r["depth"]))
        d = [int(r["depth"]) for r in prow]
        axes[2].plot(d, [float(r["purity"]) for r in prow], color=c, marker="o",
                     markersize=3.5, linewidth=1.1)
        axes[2].plot(d, [float(r["null_mean"]) for r in prow], color=c, linewidth=1.0,
                     linestyle=":")
    for ax in axes:
        ax.set_xticks([1, 2, 3, 4])
        ax.set_xlim(.7, 4.3)
        ax.grid(axis="y")
    axes[0].set_ylim(0, 60)
    axes[0].set_xlabel("Digit")
    axes[0].set_ylabel("Embedding variance (%)")
    axes[0].set_title("(a) Variance explained")
    axes[1].set_ylim(0, .6)
    axes[1].set_xlabel("Digit")
    axes[1].set_ylabel("Category AMI")
    axes[1].set_title("(b) Category information")
    axes[2].set_ylim(0, 1.05)
    axes[2].set_xlabel("Prefix depth")
    axes[2].set_ylabel("Category purity")
    axes[2].set_title("(c) Category purity")
    handles = [Line2D([], [], color=QCOLOR[q], lw=2, label=QNAME[q]) for q in QORDER]
    handles += [Line2D([], [], color=P.INK, marker="o", markersize=3.5, label="Digit alone"),
                Line2D([], [], color=P.INK, marker="o", markersize=3.5, linestyle="--",
                       markerfacecolor="white", label="Given earlier digits"),
                Line2D([], [], color=P.INK, linestyle=":", label="Shuffled null")]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, 1.0), ncol=6,
               columnspacing=1.0, handlelength=1.6, handletextpad=.4)
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=PROJECT / "figures")
    parser.add_argument("--preview-dir", type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    t = read_sources()
    P.configure()
    finish(decoding_budget(t["decoding_cells"], t["decoding_contrasts"]),
           "sidlens_decoding_budget", args.output_dir, args.preview_dir)
    finish(fixed_orders(t["fixed_orders_cells"], t["fixed_orders_per_cell"]),
           "sidlens_fixed_orders", args.output_dir, args.preview_dir)
    finish(digit_structure(t["digit_structure"], t["category_purity"]),
           "sidlens_digit_structure", args.output_dir, args.preview_dir)


if __name__ == "__main__":
    main()
