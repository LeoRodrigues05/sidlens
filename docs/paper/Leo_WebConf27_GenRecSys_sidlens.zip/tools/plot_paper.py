#!/usr/bin/env python3
"""Re-layout six existing historical plots at their actual publication size.

From any directory: python3 paper/www2027/tools/plot_paper.py
Requires matplotlib (tested with 3.11.1); all inputs are packaged CSVs. No raw
interactions, model checkpoints, training, or inference are required. See
data/publication_manifest.json for original sources, hashes and selections.
Output PDFs are 6.9 inches wide except the 3.33-inch model-variant figure;
embed at their intended width to retain 8-point minimum type.
--preview-dir optionally writes 180-dpi PNG previews.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import fmean

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.text import Text


PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"
BLUE = "#0072B2"
ORANGE = "#D55E00"
TEAL = "#56B4A9"
INK = "#243447"
GRAY = "#BEC6CF"
TOKENIZERS = ["RQ-VAE", "RQ-KMeans", "MQ"]


def read_sources():
    manifest = json.loads((DATA / "publication_manifest.json").read_text())
    tables = {}
    for key, source in manifest["sources"].items():
        path = DATA / source["packaged_csv"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != source["packaged_sha256"]:
            raise ValueError(f"Audited input changed: {path.name}")
        with path.open(newline="") as handle:
            tables[key] = list(csv.DictReader(handle))
        assert len(tables[key]) == source["rows"]
    return tables


def configure():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8.5,
        "axes.titlesize": 9, "axes.titleweight": "bold",
        "axes.labelsize": 8.5, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "legend.fontsize": 8, "legend.frameon": False,
        "text.color": INK, "axes.labelcolor": INK,
        "xtick.color": INK, "ytick.color": INK,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": GRAY, "axes.linewidth": 0.6,
        "axes.axisbelow": True, "grid.color": "#E5E8EC",
        "grid.linewidth": 0.5, "lines.linewidth": 1.0,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "figure.facecolor": "white", "savefig.facecolor": "white",
    })


def finish(fig, name, output_dir, preview_dir):
    fig.canvas.draw()
    small = [t.get_fontsize() for t in fig.findobj(Text)
             if t.get_visible() and t.get_text() and t.get_fontsize() < 8]
    if small:
        raise ValueError(f"Font below 8 pt in {name}: {small}")
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if (box.x0 < -.5 or box.y0 < -.5 or box.x1 > fig.bbox.x1 + .5
                or box.y1 > fig.bbox.y1 + .5):
            raise ValueError(f"Text outside print canvas in {name}: {text.get_text()!r}")
    # Do not use bbox_inches='tight': it changes the intended print dimensions.
    path = output_dir / f"pub_{name}.pdf"
    fig.savefig(path, metadata={"Creator": "tools/plot_paper.py",
                               "CreationDate": None, "ModDate": None})
    if preview_dir:
        preview_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(preview_dir / f"pub_{name}.png", dpi=180)
    print(f"{path.name}: {fig.get_figwidth():.2f} × {fig.get_figheight():.2f} in; font ≥8 pt")
    plt.close(fig)


def dot_handle(color, marker, label):
    return Line2D([], [], color=color, marker=marker, linestyle="none",
                  markersize=4.5, label=label)


def cross_dataset(rows):
    """32 original gaps and four means; use rows to avoid overlapping slopes."""
    assert len(rows) == 8
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.7), sharey=True)
    fig.subplots_adjust(left=0.17, right=0.985, bottom=0.22, top=0.81, wspace=0.16)
    labels = [f"{r['tokenizer']} · {r['depth']}" for r in rows] + ["Mean"]
    y = list(range(len(labels)))
    for ax, stem, title in zip(axes, ("hr10", "ndcg10"), ("(a) Hit@10 gap", "(b) NDCG@10 gap")):
        values = [[float(r[f"{stem}_{dataset}_gap_pp"]) for r in rows]
                  for dataset in ("industrial", "office")]
        for series in values:
            series.append(fmean(series))
        ax.hlines(y, values[0], values[1], color=GRAY, linewidth=1.2)
        ax.axvline(0, color="#7C8794", linewidth=0.8)
        ax.axhline(7.5, color=GRAY, linewidth=0.6)
        for series, color, marker in zip(values, (BLUE, ORANGE), ("o", "s")):
            ax.scatter(series, y, color=color, marker=marker, s=20, zorder=3)
            ax.annotate(f"{series[-1]:+.2f}", (series[-1], y[-1]),
                        xytext=(0, -12), textcoords="offset points", ha="center",
                        fontsize=8, color=color)
        ax.set_yticks(y, labels)
        ax.set_ylim(8.95, -0.65)
        ax.set_xlim(-6, 10)
        ax.set_xticks([-5, 0, 5, 10])
        ax.set_title(title, loc="left", pad=5)
        ax.grid(axis="x")
        ax.tick_params(axis="y", length=0)
    fig.legend(handles=[dot_handle(BLUE, "o", "Industrial"),
                        dot_handle(ORANGE, "s", "Office")],
               loc="upper center", bbox_to_anchor=(0.57, 1.01), ncol=2)
    fig.text(0.57, 0.02, "DiffGRM − AR (percentage points); positive favors DiffGRM",
             ha="center", fontsize=8.5)
    return fig


def resource_cost(rows):
    """All 28 original stacked GPU-hour bars and their evaluation shares."""
    assert len(rows) == 28
    assert {(r["Dataset"], r["GPU count"], r["GPU model"]) for r in rows} == {
        ("Industrial", "4", "NVIDIA A100-SXM4-40GB")}
    fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.8), sharex=True)
    fig.subplots_adjust(left=0.10, right=0.982, bottom=0.19, top=0.78, wspace=0.68)
    groups = [("next-item", {"128"}, "(a) Next item · B=128"),
              ("next-item", {"512"}, "(b) Next item · B=512"),
              ("next-2-item", {"256", "512"}, "(c) Next two · B=256*")]
    short = {"RQ-VAE": "VAE", "RQ-KMeans": "RK", "MQ": "MQ"}
    for ax, (task, codebooks, title) in zip(axes, groups):
        part = sorted([r for r in rows if r["Task"] == task and r["Codebook"] in codebooks],
                      key=lambda r: (int(r["Codebook"]), TOKENIZERS.index(r["Tokenizer"]), int(r["Depth"])))
        y = list(range(len(part)))
        train = [float(r["Train GPU-h"]) for r in part]
        evaluation = [float(r["Eval GPU-h"]) for r in part]
        ax.barh(y, train, height=0.70, color=BLUE, label="Training")
        ax.barh(y, evaluation, left=train, height=0.70, color=TEAL, label="Evaluation")
        labels = [f"{short[r['Tokenizer']]} {r['Depth']}" +
                  ("*" if task == "next-2-item" and r["Codebook"] == "512" else "") for r in part]
        ax.set_yticks(y, labels)
        ax.set_ylim(9.65, -0.65)
        ax.set_xlim(0, 11.5)
        ax.set_xticks([0, 3, 6, 9])
        ax.set_title(title, loc="left", fontsize=8.5, pad=6)
        ax.grid(axis="x")
        ax.tick_params(axis="y", length=0, pad=3)
        for yi, tr, ev in zip(y, train, evaluation):
            ax.text(tr + ev + 0.18, yi, f"{100 * ev / (tr + ev):.1f}%",
                    va="center", fontsize=8)
    fig.legend(handles=[Patch(color=BLUE, label="Training"), Patch(color=TEAL, label="Evaluation")],
               loc="upper left", bbox_to_anchor=(0.085, 1.005), ncol=2)
    fig.text(0.985, 0.95, "Bar-end labels: evaluation share", ha="right", fontsize=8)
    fig.text(0.53, 0.087, "GPU-hours (four A100-SXM4-40GB GPUs)", ha="center", fontsize=8.5)
    fig.text(0.53, 0.012, "VAE: RQ-VAE; RK: RQ-KMeans; number: depth.  *MQ 3 uses B=512.",
             ha="center", fontsize=8)
    return fig


def slot_decomposition(rows):
    """All original marginal and composition values, at k=10 and B=256."""
    assert len(rows) == 9 and {r["n"] for r in rows} == {"3452"}
    rows = sorted(rows, key=lambda r: (TOKENIZERS.index(r["tokenizer"]), int(r["depth"])))
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.7), sharey=True)
    fig.subplots_adjust(left=0.17, right=0.985, bottom=0.24, top=0.80, wspace=0.19)
    y = list(range(len(rows)))
    labels = [f"{r['tokenizer']} · {r['depth']}" for r in rows]
    first = [float(r["first@10"]) for r in rows]
    second = [float(r["second@10"]) for r in rows]
    axes[0].hlines(y, second, first, color=GRAY, linewidth=1.1)
    axes[0].scatter(first, y, color=BLUE, marker="o", s=22, zorder=3, label="Slot 1")
    axes[0].scatter(second, y, color=ORANGE, marker="s", s=22, zorder=3, label="Slot 2")
    axes[0].set_xlim(0, 25)
    axes[0].set_xticks([0, 5, 10, 15, 20, 25])
    axes[0].set_xlabel("Slot recovery at k=10 (%)")
    axes[0].legend(loc="lower center", bbox_to_anchor=(0.5, 1.02), ncol=2,
                   handletextpad=0.4, columnspacing=1.3, borderaxespad=0)
    first_only = [float(r["first_only@10"]) for r in rows]
    second_only = [float(r["second_only@10"]) for r in rows]
    both = [float(r["either@10"]) - a - b for r, a, b in zip(rows, first_only, second_only)]
    bottom = [0.0] * len(rows)
    for values, color, label in zip((both, first_only, second_only), (TEAL, BLUE, ORANGE),
                                    ("Both", "Slot 1 only", "Slot 2 only")):
        axes[1].barh(y, values, left=bottom, color=color, height=0.68,
                     edgecolor="white", linewidth=0.35, label=label)
        bottom = [a + b for a, b in zip(bottom, values)]
    axes[1].set_xlim(0, 30)
    axes[1].set_xticks([0, 5, 10, 15, 20, 25, 30])
    axes[1].set_xlabel("Recovery composition at k=10 (%)")
    axes[1].legend(loc="lower center", bbox_to_anchor=(0.5, 1.02), ncol=3,
                   handlelength=0.8, handletextpad=0.3, columnspacing=0.65,
                   borderaxespad=0)
    for ax in axes:
        ax.set_yticks(y, labels)
        ax.set_ylim(8.7, -0.7)
        ax.grid(axis="x")
        ax.tick_params(axis="y", length=0)
    fig.text(0.17, 0.955, "(a) Recovery by position", weight="bold", fontsize=9)
    fig.text(0.615, 0.955, "(b) Recovery composition", weight="bold", fontsize=9)
    fig.text(0.57, 0.025, "Both slots may be recovered in different candidate pairs.",
             ha="center", fontsize=8)
    return fig


def cce_rank_reversal(rows):
    """Preserve all 18 original ranks plus both sets of explicitly shown scores."""
    assert len(rows) == 18 and {r["examples"] for r in rows} == {"3681"}
    for metric, rank in (("sid_hit_pct", "sid_hit_rank"),
                         ("cce_item_hit_pct", "cce_item_hit_rank")):
        values = [float(r[metric]) for r in rows]
        assert all(int(r[rank]) == 1 + sum(v > float(r[metric]) for v in values) for r in rows)
    rows = sorted(rows, key=lambda r: int(r["sid_hit_rank"]))
    fig, ax = plt.subplots(figsize=(6.9, 3.8))
    fig.subplots_adjust(left=0.205, right=0.70, bottom=0.12, top=0.88)
    y = list(range(len(rows)))
    raw = [int(r["sid_hit_rank"]) for r in rows]
    corrected = [int(r["cce_item_hit_rank"]) for r in rows]
    names = {"rqkmeans": "RQ-KMeans", "rqvae": "RQ-VAE", "MQ": "MQ"}
    labels = [f"{names[r['method_key']]} {r['depth']}×{r['codebook_size']}" for r in rows]
    ax.hlines(y, raw, corrected, color=GRAY, linewidth=1.3)
    ax.scatter(raw, y, color=BLUE, marker="o", s=28, zorder=3)
    ax.scatter(corrected, y, color=ORANGE, marker="s", s=13, zorder=3)
    ax.set_yticks(y, labels)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(0.3, 18.7)
    ax.set_ylim(17.65, -0.65)
    ax.set_xticks([1, 5, 10, 15, 18])
    ax.set_xticks(range(1, 19), minor=True)
    ax.grid(axis="x", which="major")
    ax.set_xlabel("Rank (1 = highest score)")
    fig.legend(handles=[dot_handle(BLUE, "o", "SID Hit@10"),
                        dot_handle(ORANGE, "s", "CCE ItemHit@10")],
               loc="upper left", bbox_to_anchor=(0.18, 1.005), ncol=2,
               columnspacing=1.4)
    # Use data y coordinates for the score table, preserving the ranking rows.
    for x, label in ((1.22, "SID Hit\n@10 (%)"), (1.49, "CCE ItemHit\n@10 (%)")):
        ax.text(x, 1.035, label, transform=ax.transAxes, ha="center", va="bottom",
                fontsize=8, weight="bold", clip_on=False)
    for yi, row in zip(y, rows):
        for x, key in ((1.22, "sid_hit_pct"), (1.49, "cce_item_hit_pct")):
            ax.text(x, yi, f"{float(row[key]):.2f}", transform=ax.get_yaxis_transform(),
                    ha="center", va="center", fontsize=8, clip_on=False)
    return fig


def gap_by_depth(rows, means):
    """All 70 original metric gaps, with original 12 mean/count annotations."""
    assert len(rows) == 35 and len(means) == 12
    colors = {"RQ-VAE": BLUE, "RQ-KMeans": ORANGE, "MQ": "#8A5DA2"}
    markers = {128: "o", 256: "s", 512: "^"}
    fig, axes = plt.subplots(1, 4, figsize=(6.9, 2.8), sharey=True)
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.25, top=0.72, wspace=0.18)
    for ax, (dataset, metric) in zip(axes, [(d, m) for d in ("Industrial", "Office")
                                         for m in ("HR@10", "NDCG@10")]):
        part = [r for r in rows if r["dataset"] == dataset]
        for row in part:
            t = TOKENIZERS.index(row["tokenizer"])
            b = int(row["codebook"])
            offset = (t - 1) * .1 + (b == 512) * .025 - (b == 128) * .025
            ax.scatter(int(row["depth"]) + offset, float(row[f"{metric}_gap"]),
                       color=colors[row["tokenizer"]], marker=markers[b], s=16,
                       alpha=.85, edgecolor="white", linewidth=.3, zorder=3)
        summary = sorted([r for r in means if r["dataset"] == dataset and r["metric"] == metric],
                         key=lambda r: int(r["depth"]))
        for row in summary:
            selected = [float(r[f"{metric}_gap"]) for r in part if r["depth"] == row["depth"]]
            assert len(selected) == int(row["paired_configurations"])
            assert abs(fmean(selected) - float(row["mean_gap"])) < 1e-12
        ax.plot([int(r["depth"]) for r in summary], [float(r["mean_gap"]) for r in summary],
                color=INK, marker="D", markersize=3, linewidth=1.2, zorder=4)
        ax.axhline(0, color="#7C8794", linewidth=.7)
        ax.set_xlim(2.65, 5.35)
        ax.set_ylim(-9, 11)
        ax.set_yticks([-5, 0, 5, 10])
        # Put exact original mean/count labels below the axis, clear of points.
        ax.set_xticks([3, 4, 5], [f"{r['depth']}\n{float(r['mean_gap']):+.2f}\nn={r['paired_configurations']}"
                                  for r in summary])
        ax.set_title(f"{dataset}\n{'Hit@10' if metric == 'HR@10' else metric}", fontsize=8.5)
        ax.grid(axis="y")
    axes[0].set_ylabel("DiffGRM − AR (pp)")
    handles = [Line2D([], [], color=colors[t], lw=2, label=t) for t in TOKENIZERS]
    handles += [dot_handle("#607084", markers[b], f"B={b}") for b in (128, 256, 512)]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.53, 1.01),
               ncol=6, columnspacing=1.0, handlelength=1.2, handletextpad=.4)
    fig.text(.53, .018, "SID depth; labels below each depth give mean gap and pair count. Diamonds: means.",
             ha="center", fontsize=8)
    return fig


def model_variants(rows):
    """All 11 reported rows, including both ambiguous Qwen RQ-VAE rows."""
    assert len(rows) == 11
    colors = {"RQ-VAE": BLUE, "RQ-KMeans": ORANGE, "MQ": "#8A5DA2"}
    fig, ax = plt.subplots(figsize=(3.33, 3.0))
    fig.subplots_adjust(left=.44, right=.91, bottom=.18, top=.88)
    labels, ticks = [], []
    cursor = 0
    for tokenizer in TOKENIZERS:
        part = sorted([r for r in rows if r["tokenizer"] == tokenizer], key=lambda r: float(r["HR@10"]))
        start = cursor
        for row in part:
            h, n = float(row["HR@10"]), float(row["NDCG@10"])
            ax.hlines(cursor, n, h, color=GRAY, linewidth=1.0)
            ax.scatter(h, cursor, color=colors[tokenizer], marker="o", s=17, zorder=3)
            ax.scatter(n, cursor, edgecolor=colors[tokenizer], facecolor="white", marker="s", s=17, zorder=3)
            ax.annotate(f"{h:.2f}", (h, cursor), xytext=(3, 0), textcoords="offset points",
                        va="center", fontsize=8)
            ticks.append(cursor)
            labels.append(f"{row['model']} [{row['source_row']}]")
            cursor += 1
        ax.text(1.095, (start + cursor - 1) / 2, tokenizer, transform=ax.get_yaxis_transform(),
                rotation=90, ha="center", va="center", color=colors[tokenizer], fontsize=8)
        if tokenizer != TOKENIZERS[-1]:
            ax.axhline(cursor - .15, color=GRAY, linewidth=.5)
        cursor += .8
    ax.set_yticks(ticks, labels)
    ax.tick_params(axis="y", length=0, pad=3)
    ax.set_ylim(cursor - 1.25, -.7)
    ax.set_xlim(7, 23)
    ax.set_xticks([8, 12, 16, 20])
    ax.grid(axis="x")
    ax.set_xlabel("Reported metric (%)")
    fig.legend(handles=[dot_handle(INK, "o", "Hit@10"),
                        Line2D([], [], color=INK, marker="s", markerfacecolor="white",
                               linestyle="none", markersize=4.5, label="NDCG@10")],
               loc="upper center", bbox_to_anchor=(.58, 1.01), ncol=2,
               handletextpad=.35, columnspacing=1.1)
    fig.text(.51, .012, "[ ]: original reported row", ha="center", fontsize=8)
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=PROJECT / "figures")
    parser.add_argument("--preview-dir", type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    tables = read_sources()
    configure()
    for name, plotter in (("cross_dataset_gap", cross_dataset),
                          ("ar_resource_cost", resource_cost),
                          ("ar_slot_decomposition", slot_decomposition),
                          ("cce_rank_reversal", cce_rank_reversal),
                          ("gap_by_depth", lambda r: gap_by_depth(r, tables["gap_by_depth_means"])),
                          ("model_variants", model_variants)):
        finish(plotter(tables[name]), name, args.output_dir, args.preview_dir)


if __name__ == "__main__":
    main()
