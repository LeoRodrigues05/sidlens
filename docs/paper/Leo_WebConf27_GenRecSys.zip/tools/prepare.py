#!/usr/bin/env python3
"""Regenerate the audited table and package the complete Overleaf project.

Run from any directory: python3 paper/www2027/tools/prepare.py
Uses only the Python standard library; does not run training or inference.
"""

import csv
import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / "data" / "historical_cce.csv"
SOURCE_SHA256 = "74d291d9e931c00061295de95e6118b46dc1466b5a7cd12bdd2c66e6b1ff3b78"


def prepare():
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise ValueError("Historical source differs from the audited CSV")
    with SOURCE.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    grid = {(r["method"], int(r["digits"]), int(r["size"])) for r in rows}
    expected = {(m, d, b) for m in ("MQ", "rqkmeans", "rqvae")
                for d in (3, 4, 5) for b in (128, 512)}
    if len(rows) != 18 or grid != expected or any(int(r["examples"]) != 3681 for r in rows):
        raise ValueError("Unexpected historical cohort/grid")
    names = {"MQ": "Parallel MQ", "rqkmeans": "RQ-KMeans", "rqvae": "RQ-VAE"}
    lines = [
        "% Generated from data/historical_cce.csv by tools/prepare.py.",
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{All audited historical Industrial next-item AR configurations.",
        r"Scores and collision rates are percentages. Each row uses 3,681 examples",
        r"from 1,606 users and one retained training run. These are historical",
        r"cohort results, not the revised v3 comparison. Collision rate counts",
        r"catalog items in non-singleton complete-SID groups.}",
        r"\label{tab:historical-cce}",
        r"\begin{tabular}{lrrrrrr}",
        r"\toprule",
        r"SID family & $D\times B$ & SID Hit@10 & CCE ItemHit@10 & SID NDCG@10 & CCE ItemNDCG@10 & Collisions (\%) \\",
        r"\midrule",
    ]
    previous = None
    for row in rows:
        if previous is not None and previous != row["method"]:
            lines.append(r"\midrule")
        fields = [names[row["method"]], f"${row['digits']}\\times{row['size']}$"]
        fields.extend(f"{float(row[key]):.4f}" for key in (
            "sid_hit10_pct", "cce_item_hit10_pct", "sid_ndcg10_pct", "cce_item_ndcg10_pct"))
        fields.append(f"{float(row['collision_items_pct']):.2f}")
        lines.append(" & ".join(fields) + r" \\")
        previous = row["method"]
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""])
    table = PROJECT / "tables" / "historical_cce.tex"
    table.parent.mkdir(exist_ok=True)
    table.write_text("\n".join(lines))

    # Explicit allowlist: no checkpoints, raw interaction data, or TeX logs.
    # Supporting results are internal drafting material, not a submission PDF.
    files = [PROJECT / name for name in (
        "main.tex", "references.bib", "latexmkrc", "README.md",
        "RESEARCH_PLAN.md", "SOURCES.md", "RESULT_INVENTORY.md",
        "tools/prepare.py", "tools/plot_paper.py",
    )]
    files += sorted((PROJECT / "sections").glob("*.tex"))
    files += sorted((PROJECT / "tables").glob("*.tex"))
    for directory in ("figures", "data", "supporting_results"):
        files += sorted(path for path in (PROJECT / directory).rglob("*")
                        if path.is_file() and path.suffix.lower() in
                        {".pdf", ".csv", ".tsv", ".json", ".md", ".html", ".sha256"})
    missing = [str(path.relative_to(PROJECT)) for path in files if not path.is_file()]
    if missing:
        raise ValueError(f"Missing project assets: {missing}")
    archive = PROJECT.parent / "onediffrec-www2027-overleaf.zip"
    with ZipFile(archive, "w", compression=ZIP_DEFLATED) as output:
        for path in files:
            output.write(path, path.relative_to(PROJECT))
    with ZipFile(archive) as check:
        if check.testzip() is not None or "main.tex" not in check.namelist():
            raise ValueError("Invalid project archive")
    print(f"Regenerated {table.relative_to(PROJECT)} ({len(rows)} audited rows)")
    print(f"Packaged {archive} ({archive.stat().st_size:,} bytes)")


if __name__ == "__main__":
    prepare()
